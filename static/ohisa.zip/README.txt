Welcome!

These steps are version 0.1 of an Open Home Internet Security Architecture (ohisa).  Knowing what tools to use is one chore.  Knowing how to do something with them is another chore.  This project starts with what SHOULD be a robust design and is accompanied by initial configs that either work or require little additional attention to get them to work (enter YOUR ip scheme for at home, or enter YOUR password, etc.).

The intent is to improve security for entire networks with low user count and low bandwidth requirements (i.e. at home) by utilizing existing tools.

These instructions heavily rely upon CLOUD environments.  With some adaptation (and lots of servers and electricity), these can be adapted for a non-CLOUD configuration.

Versioning is expected based on unclear steps, just plain bugs, or minor tweaks to security design.

Goals:

* Prevent ISP from snooping on traffic ... and from gleaning intelligence from your DNS queries
* Reduce your exposure / visibility to ad networks
* Improve your HTTP/HTTPS security
* Improve your DNS security
* Give you control w/o burning mass quantities of your time


Random note: *INTERNET* was chosen instead of *NETWORK* to avoid inadvertent and specifically unwanted attention based on acronym similarity.







Presented by: Maren Peasley
Presented to: DC541
Presented on: Saturday, May 12th, 2018