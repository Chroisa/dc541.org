This section is coming in a planned future update.

This is specifically to make use of the bottom section of 1.1 of ToR Bridge Specification to essentially have your own personal driveway onto ToR (for your home network):

https://gitweb.torproject.org/torspec.git/tree/attic/bridges-spec.txt

Namely:

BridgeRelay 1
PublishServerDescriptor 0

...but this hasn't been built out yet, nor integrated with the rest of the environment.